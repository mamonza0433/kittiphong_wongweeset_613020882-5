package com.myweb.ass7dialogrv

data class Employees(val name: String, val gender: String, var mail: String, var salary: Int) {
}